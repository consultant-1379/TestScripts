#!bin/sh/bash

#Script to check the shm job status

#echo -e "SHM JOB STATUS AS ON $(date +%b" "%d)"

#cli_app 'shm status --all'|grep $(date +%d/%m/%Y)

#script to list the failed jobs

cli_app 'shm status --all'|grep $(date +%d/%m/%Y)|egrep "FAILED" > output.txt

if [ -s output.txt ]
then
  echo ""
  echo -e  "\e[1;32mBelow are the Failed SHM jobs as on  $(date +%b" "%d):\e[0m"|sed "s/^/\t/g"
  
  echo ""   
  echo   "===================================================================" | sed "s/^/\t/g"
  
  echo ""  
  echo  -e "\e[1;34mFailed or Skipped SHM Backup Jobs:\e[0m" | sed "s/^/\t/g"
  echo ""
  cat output.txt | egrep -w "BACKUP" | egrep "FAILED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;36mFailed or Skipped SHM Backup Housekeeping Jobs:\e[0m" | sed "s/^/\t/g"
  cat output.txt | egrep -w "BACKUP_HOUSEKEEPING" | egrep "FAILED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;32mFailed or Skipped SHM Delete Backup Jobs:\e[0m" | sed "s/^/\t/g"
  echo ""
  cat output.txt | egrep -w "DELETEBACKUP" | egrep "FAILED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;34mFailed or Skipped SHM Upgrade Jobs:\e[0m" | sed "s/^/\t/g"
  echo " "
  cat output.txt | egrep -w "UPGRADE" | egrep "FAILED" | sed "s/^/\t/g"
  echo ""
  echo -e "\e[1;36mFailed or Skipped SHM Delete Upgrade Package Jobs:\e[0m" | sed "s/^/\t/g"
  cat output.txt | egrep -w "DELETE_UPGRADEPACKAGE" | egrep "FAILED" | sed "s/^/\t/g"

 echo " "
 echo " "

  echo -e "===============================================================" | sed "s/^/\t/g"
  echo -e "\e[1;32m Failed jobs Found !!!! Copying server logs\e[0m"| sed "s/^/\t/g"
  echo -e "===============================================================" | sed "s/^/\t/g"

echo " "
echo " "
      sh collect_log.sh 

else
     echo "================================================="
      echo "There are no failed jobs as on $(date +%b" "%d)"
     echo "================================================="
fi
