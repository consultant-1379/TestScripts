#!/bin/bash/python
#import datetime
import os

os.system('sh shmstatus.sh')
