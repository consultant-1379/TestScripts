#!/bin/bash

#script to collect shmvm logs from cloud server

keypair="/var/tmp/enm_keypair.pem"


 consul_members='consul_members.txt'    


    ssh -o StrictHostKeyChecking=no -tt -i ${keypair} cloud-user@$EMP "exec sudo -i" consul members list|grep -i shm >${consul_members}     

     JBOSSLOG="/ericsson/3pp/jboss/standalone/log/server.log*"
     

     for ip in $(awk '{print $1}' ${consul_members});  

     do
     echo ""
     echo -e "\e[1;32m ...........Copying logs of ${ip}..........\e[0m"| sed "s/^/\t/g"
     echo ""
     ssh -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -i ${keypair} cloud-user@$EMP "ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=150 -tt -i ${keypair} cloud-user@$ip "exec sudo " tar -zcvf /ericsson/enm/dumps/shmautomatedlogs/${ip}_$(date +'%F')_$(date +'%H%M%S')_server.log.tgz -P ${JBOSSLOG}"
#scp ${JBOSSLOG} /ericsson/enm/dumps/shmautomatedlogs/${ip}_$(date +'%F')_$(date +'%H%M%S')_server.log"
     
    echo ""
    echo -e "Logs copied successfully" | sed "s/^/\t/g"
   
    done

echo ""
echo "=====================================================" |sed "s/^/\t/g"
echo ""
echo -e "\e[1;32m  Logs are copied to /ericsson/enm/dumps in shmvm\e[0m" | sed "s/^/\t/g"
echo " "
echo "=====================================================" | sed "s/^/\t/g"

echo ""

echo "Cleaning-up files older than 5 days..."
echo "..."
ssh -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -i ${keypair} cloud-user@$EMP "exec " find /ericsson/enm/dumps/shmautomatedlogs/ -mmin +5 -name '*.tgz' -delete
echo "..."
echo "Cleaning-up done."
echo ""

 
