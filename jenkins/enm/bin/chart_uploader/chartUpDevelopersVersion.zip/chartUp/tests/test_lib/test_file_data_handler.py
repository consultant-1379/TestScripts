import unittest
from proj.bin.lib.file_data_handler import FileDataHandler

class TestFileDataHandler(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.fdh = FileDataHandler()

    def test_merge_dicts(self):
        # Note. Sort method is used as function can scramble up the list inside the dict.
        d1 = {u'Test 1': ['name1', 'name2'], u'Test 2': ['1', '2']}

        # test 1
        d2 = {u'Test 1': ['name1', 'name3'], u'Test 2': ['2', '3'], u'Test 3': ['test1']}
        expected_res = {u'Test 1': ['name1', 'name2', 'name3'], u'Test 2': ['1', '2', '3'], u'Test 3': ['test1']}
        res = self.fdh.merge_dicts(d1, d2)
        self.assertEqual({x:sorted(res[x]) for x in res.keys()}, expected_res)

        # test 2 with 1 empty list
        res2 = self.fdh.merge_dicts(d1, {})
        self.assertEqual({x:sorted(res2[x]) for x in res2.keys()}, d1)

        # test 3
        self.assertEqual(self.fdh.merge_dicts({}, {}), {})