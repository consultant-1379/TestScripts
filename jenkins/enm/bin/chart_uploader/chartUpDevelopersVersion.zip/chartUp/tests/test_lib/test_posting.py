import unittest
from proj.bin.lib.posting import PostHelper

class TestPostHelper(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.ph = PostHelper()

    def test_check_if_excel_file_extension(self):
        self.assertTrue(self.ph.check_if_excel_file_extension(file_path=r'C:\some\path\file_name.xlsm'))
        self.assertTrue(self.ph.check_if_excel_file_extension(file_path=r'C:\some\path\file_name.xlsx'))
        self.assertRaises(ValueError, self.ph.check_if_excel_file_extension, file_path=r'C:\some\path\file_name')
        self.assertRaises(ValueError, self.ph.check_if_excel_file_extension, file_path=r'C:\some\path\file_name.xlsh1')
        self.assertRaises(ValueError, self.ph.check_if_excel_file_extension, file_path=r'')
