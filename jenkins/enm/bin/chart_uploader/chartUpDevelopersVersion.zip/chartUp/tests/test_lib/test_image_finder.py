import unittest
from proj.bin.lib.image_finder import ImageFinder

class TestImageFinder(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.imgF = ImageFinder(path_where_to_look=r"C:\some\path")

    def test_getImagePathByName(self):
        self.assertEqual(self.imgF.getImagePathByName("test1"), r"C:\some\path\test1.png")


