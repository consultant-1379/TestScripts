import unittest


class TestSaveGraph(unittest.TestCase):
    def test_getAllSheetNames(self):
        pass


    def test_saveGraphsFromAllSheets(self):
        pass

if __name__ == '__main__':
    unittest.main()
