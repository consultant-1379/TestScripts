import unittest


class TestUpdateReport(unittest.TestCase):
    def test_push_image_on_server(self):
        pass

    def test_edit_report_page_value(self):
        pass

    def test_get_report_page_id(self):
        pass

    def test_get_observations_table_code(self):
        pass

    def test_get_jira_table_code(self):
        pass

    def test_get_file_multipart_encoder(self):
        pass

    def test_upload_picture_to_attachments(self):
        pass

    def test_update_picture_in_attachemnts(self):
        pass

    def test_get_image_editor_value(self):
        pass

    def test_update_page_with_image(self):
        pass

    def test_get_current_attac_names_and_ids(self):
        pass

if __name__ == '__main__':
    unittest.main()
