import unittest


class TestDragNDropWidget(unittest.TestCase):
    def test_set_remove_on_drag(self):
        pass

    def test_set_bound_axis_positions(self):
        pass

    def test_on_touch_down(self):
        pass

    def test_on_touch_up(self):
        pass

    def test_on_touch_move(self):
        pass

    def test_easy_access_dnd(self):
        pass

    def test_on_motion(self):
        pass

    def test_on_motion_over(self):
        pass

    def test_on_motion_out(self):
        pass

    def test_on_drag_start(self):
        pass

    def test_on_drag_finish(self):
        pass

    def test_deparent(self):
        pass

    def test_reborn(self):
        pass

    def test_reparent(self):
        pass


if __name__ == '__main__':
    unittest.main()
