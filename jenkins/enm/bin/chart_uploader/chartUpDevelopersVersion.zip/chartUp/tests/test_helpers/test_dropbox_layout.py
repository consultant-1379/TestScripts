import unittest


class TestDropboxLayout(unittest.TestCase):

    def test_drop_obj(self):
        pass

    def test_already_added(self):
        pass

    def test_get_total_button_height(self):
        pass

    def test_remove_button(self):
        pass

    def test_add_to_widget_size(self):
        pass

    def test_subtract_from_widget_size(self):
        pass



