---=== CHART UPLOADER ===---

- INTRODUCTION:
App that extracts charts from specified excel file and makes it easier for user to upload them to confluence - endurance test reports.
User drags and drops charts to reports he/she wants them to be uploaded. 
Charts later appears in attachments ("https://confluence-nam.lmera.ericsson.se/pages/viewpageattachments.action?pageId=<ID>")  and report page it self ("https://confluence-nam.lmera.ericsson.se/pages/viewpage.action?spaceKey=TORRV&title=<TITLE_SEPERATED_BY_PLUS_SIGN>").

Uploaded graphs will appear under the header "Key Observations"(If not present, than on top of the page).

Written in Python and Kivy(For user interface).

- STRUCTURE:
-/Project+
		 |-/app+
		 |     |-/bin+
		 |     |	 |-/helpers+
		 |     |	 |	       | '__init__.py'
		 |     |	 |		   |-'dragable_button.py'
		 |     |	 |		   |-'drag_n_drop_widget.py'
		 |     |	 |	       |-'dropbox_layout.py'
		 |     |	 |	       |-'popup.py'
		 |     |	 |-/images
		 |     |	 |-/screens+
		 |     |	 |	       |-'__init__.py'
		 |     |	 |	       |-'howto.py'
		 |     |	 |		   |-'login.py'
		 |     |	 |		   |-'post.py'
		 |     |	 |	       |-'postnext.py'
		 |     |	 |-'HowTo.txt'
		 |     |-/lib+
		 |           |-/graphs
		 |           |-'__init__.py'
		 |           |-'constants.py'
		 |           |-'file_data_handler.py'
		 |           |-'image_finder.py'
		 |           |-'page_scraper.py'
		 |           |-'posting'
		 |           |-'save_graph.py'
		 |           |-'update_report.py'
		 |           |-'confluenceVsExcel.txt'
		 |-/logs
		 |-'howto.kv'
		 |-'login.kv'
		 |-'menu.kv'
		 |-'post.kv'
		 |-'postnext.kv'
		 |-'__init__.py'
		 |-'main.py'
-/tests+
	   |-/test_helpers
	   |-/test_lib

1.0 /app:
        Contains almost all back end data(Some would be outside this folder in main.py).
1.1 /bin:
		Contains files dealing with UI.
1.1.1 /helpers:
		contains files that helps to handle events on the screens like button drags, pop-ups etc.
1.1.1.1 drag_n_drop_widget.py:
		Class DragNDropWidget:
			Widget that is inherited by 'DragableButton'. Essentially adds functionality to Kivy button e.g. makes it draggable. 
1.1.1.2 dragable_button.py:
		Class DragableButton:
			Button class that inherits Kivy 'Button' and 'DragNDropWidget'.
1.1.1.3 dropbox_layout.py:
		Class DropboxLayoutWidget:
			Widget that is inherited by 'DropboxLayout' class. Essentially adds functionality to Kivy StackLayout to handle different events e.g. dropped 'DragableButton' gets added in.
		Class DropboxLayout:
			Class that inherit kivy StackLayout and 'DropboxLayoutWidget'. Is used to create objects that are rows in postnext. Each row holds Label, dropped chart buttons and count of dropped charts in a row.
		Class SplitLine:
			Kivy button that is used by 'DropboxLayoutWidget'. Represents the count of dropped 'DragNDropWidget' in window postnext.
1.1.1.4 popup.py:
		Class Alert
			Uses kivy Popup class to display different popups like warning messages or other windows such as user login etc.
1.1.2 /images:
		Used for graphic purposes
1.1.3 /screens:
		Contains screen handlers and its back-end.
1.1.3.1 howto.py:
		Displays howto.kv
		Class HowTo:
			Used as a popup therefore does not inherit kivy Screen.
1.1.3.2 login.py:
		Displays login.kv
		Class Login:
			Used as a popup therefore does not inherit kivy Screen.
			It creates session and promts user with login and password. If user is not logged in or his session will expire he/she will have to login using their confluence login details.
1.1.3.3 post.py:
		Displays post.kv
		Class Post:
			It makes sure user puts in correct Confluence Endurance test report and correct excel file.
		Class LoadDialog:
			Allows user to browse through your files on your local machine to find excel file easier.
		Class NextDialog:
		    Here it deletes graphs from memory that it currently has.
			Displays log entries of how users entered data is handled e.g. what graphs are pulled from excel file and which report child pages were found under Endurance test report.
			In this run it generates widgets in postnext screen such as 'dragable_button' and 'dropbox_layout' widgets.
1.1.3.4 postnext.py:
		Displays postnext.kv
		Class ImageButton:
			Allows to display popup 'howto'
		Class PostNext:
			Here user can specify charts that he/she wants to upload on specified report pages and upload them.
		Class PostNextDropFrom:
			Draggable buttons of charts are created and handled here. 'dragable_button' is used here (1.1.2).
		Class PostNextDropTo:
			This class contains a rows of Stack layouts that contains titles of found Confluence test report pages. It uses 'dropbox_layout' (1.1.3) to create its rows. Draggable button can be dropped here. 
		Class UploadDialog:
			Console window that allows user to see log entries of how the upload is executed.
1.1.4 HowTo.txt:
		Text file that is used as a kivy Layout to display user an information on how to use this tool.
1.2 /lib:
		Back-end logic
1.2.1 /graphs:
		Folder that temporarily contains charts that been pulled out from excel file. Images are only deleted when new images are pulled in.
1.2.2 constants.py:
		It contains values that are accessed by multiple classes in different packages.
1.2.3 file_data_handler.py:
		Class FileDataHandler:
			Handles text files and its data.
1.2.4 image_finder.py:
		Class ImageFinder:
			Handles charts that were pulled from excel file.
1.2.5 page_scraper.py:
		Uses beautifulsoup4 lib to scrape data from websites - in particular confluence pages.
1.2.6 posting.py:
		Class PostHelper:
			Helps to handle events that are necessarily for posting charts on confluence and prevents possible events that can cause problems. For example it will check if user has specified correct excel file.
1.2.7 save_graph.py:
		Class SaveGraph:
			Uses win32com.client Dispach import handle excel file. Main functionality is to extract charts from excel file.
1.2.8 update_report.py:
		Class UpdateReport:
			Class that handles uploads to confluence report pages. It uploads charts and under certain conditions it adds 2 additional tables for observations and jira reports.
1.2.9 confluenceVsExcel.txt:
		Is used like database. It just contains a dict of default uploads that the user has saved.
2.0 /logs:
        Logs from each days when program is run. Logs contains data of uploads and if there crash has occurred in run time it will be showed in the log. That information could be used to fix the issue.
3.0 howto.kv:
		Info popup view. Called by howto.py
4.0 login.kv:
		Login popup view. Called by login.py
5.0 menu.kv:
		Main menu screen. Called by main.py
6.0 post.kv:
		First post screen. Called by post.py
7.0 postnext.kv:
		Second post screen. Called by postnext.py
8.0 main.py:
		Displays menu.kv
		Class Menu:
			Gives user multiple options.
		Class MenuApp:
			Builds kivy UI with multiple screens.

9.0 projDict folder contains spec file that is to be runned with PyInstaller like 'python -m PyInstaller catchUp.spec' while being witin the folder. Files 'catchUp.spec' should be editted and new paths of the file should be used.