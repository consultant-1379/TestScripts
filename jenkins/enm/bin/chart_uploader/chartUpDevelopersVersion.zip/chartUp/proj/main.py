#!/usr/bin/python
"""
Date: 07/2018
Author: Janis Tihonovs
"""
__version__ = '1.1'
from kivy.config import Config
Config.set('graphics', 'width', '1400')
Config.set('graphics', 'height', '800')
Config.write()
Config.set('input', 'mouse', 'mouse,multitouch_on_demand') # disable right mouse click markers
Config.set('kivy', 'exit_on_escape', '0') # disable ESC button
from kivy.app import App
from kivy.properties import StringProperty, Clock
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition

import sys
import os
import kivy
import time

def resourcePath():
    # Needed for packaging.
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS)
    return os.path.join(os.path.abspath("."))
kivy.resources.resource_add_path(resourcePath())

import app.bin.helpers.popup

from app.bin.screens.post import Post
from app.bin.screens.postnext import PostNext

from app.lib.constants import Constants
from app.lib import logger

class Menu(Screen):
    def __init__(self, **kwargs):
        super(Menu, self).__init__(**kwargs)

        Clock.schedule_once(self.on_finish_init, 0)

    def on_finish_init(self, dt):
        app.bin.helpers.popup.Alert().userLogin()

    def post_to_confluence(self):
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'post'

    def how_to_use(self):
        app.bin.helpers.popup.Alert().howTo()

    def disconnect(self):
        Constants.session.get("https://confluence-nam.lmera.ericsson.se/logout.action")
        app.bin.helpers.popup.Alert().userLogin()

class MenuApp(App):
    username = StringProperty(None)
    password = StringProperty(None)

    def build(self):
        self.icon = 'bin/images/logo.png'
        self.title = "Chart Uploader"
        manager = ScreenManager()
        manager.add_widget(Menu(name='menu'))
        manager.add_widget(Post(name='post'))
        manager.add_widget(PostNext(name='postnext'))
        return manager


if __name__ == '__main__':
    Constants.LOGGER = logger.setup_logger(name="Chart uploader run", log_file=time.strftime("logs/%Y-%m-%d_Run.log"))
    try:
        MenuApp().run()
    except Exception as ex:
        logger.log_traceback(ex, "ERROR")
        raise Exception(ex)
