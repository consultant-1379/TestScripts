"""
Date: 07/2018
Author: Janis Tihonovs
"""
import collections


class FileDataHandler:

    @staticmethod
    def read_text_file(path):
        _file = open(path, "r")
        content = _file.read()
        _file.close()
        return content

    @staticmethod
    def merge_dicts(*dicts):
        res = collections.defaultdict(list)
        for d in dicts:
            for k, v in d.iteritems():
                res[k] = list(set(res[k] + v))
        return dict(res)
    

if __name__ == '__main__':
    FileDataHandler()

