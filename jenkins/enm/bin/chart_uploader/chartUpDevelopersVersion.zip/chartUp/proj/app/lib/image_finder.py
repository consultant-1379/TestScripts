"""
Date: 07/2018
Author: Janis Tihonovs
"""
import os
import glob

from constants import Constants


class ImageFinder:
    def __init__(self, path_where_to_look, extension='*.png'):
        self.path = path_where_to_look
        self.file_extension = extension

    def getAllFilePaths(self):
        try:
            return glob.glob(os.path.join(self.path, self.file_extension))
        except Exception as e:
            raise Exception (e.message)

    def getAllFileNames(self):
        file_extension = self.file_extension[1:] #Ignores '*' at the start of the string
        try:
            # Looks in path for all files with specific extension and returns back names of the files.
            return [file_name[:-1*(len(file_extension))] for file_name in os.listdir(self.path) if file_name.endswith(file_extension)]
        except Exception as e:
            raise Exception (e.message)

    def getImagePathByName(self, name):
        try:
            return self.path+"\\"+ name + ""+ self.file_extension[1:]
        except Exception as e:
            raise Exception (e.message)


if __name__ == '__main__':
    print ImageFinder(Constants.graph_folder_path).getImagePathByName("ActConfigTot24052018")