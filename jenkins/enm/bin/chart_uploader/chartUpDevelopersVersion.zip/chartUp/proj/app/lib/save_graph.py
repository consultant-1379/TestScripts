"""
Date: 07/2018
Author: Janis Tihonovs
"""
import pythoncom

from win32com.client import Dispatch


class SaveGraph:
    def __init__(self, xlsm_file_name, path_where_to_save):
        pythoncom.CoInitialize()
        self.app = Dispatch("Excel.Application")
        self.workbook = self.app.Workbooks.Open(Filename=xlsm_file_name)
        self.app.DisplayAlerts = False
        self.path=path_where_to_save
        self.all_real_sheets = self.getAllSheetNames()


    def getAllSheetNames(self):
        return [sheet.name for sheet in self.workbook.Worksheets]


    def saveGraphsFromAllSheets(self, log):
        """
        Method to get all charts/graphs in all sheets
        """
        try:
            log.info("Extracting charts from excel...")

            for sheet in self.workbook.Worksheets:
                log.info("@Override:Extracting charts from excel...\n\t" + sheet.name)
                # Loop though each sheet in excel file
                for i, chartObject in enumerate(sheet.ChartObjects()):
                    # Loop though each chart object in excel sheet
                    if i == 0:
                        chartObject.Chart.Export('{0}\{1}.png'.format(self.path, sheet.name))
                    else:
                        # If there is more than one graph in single excel sheet create image with name like '<sheet_name>(<i>).png'
                        chartObject.Chart.Export('{0}\{1}({2}).png'.format(self.path, sheet.name, i+1))
            log.info("@Override:Charts saved successfully!")

        except Exception as e:
            log.info("ERROR!!!\nCharts could not be saved!!!\nPlease contact product support.")
            print e.message
            raise Exception(e)
        finally:
            self.workbook.Close(SaveChanges=False)


# if __name__ == '__main__':
#     # Constants.session = requests.session()
#     # Constants.session.post(url="https://confluence-nam.lmera.ericsson.se/dologin.action",
#     #                        data={"os_username": user.name, "os_password": user.name2})
#     from app.bin.lib.constants import Constants
#     import logging
#     handler = logging.FileHandler("example.log")
#     logger = logging.getLogger("What ever")
#     logger.setLevel(logging.INFO)
#     logger.addHandler(handler)
#
#     from datetime import datetime
#     start = datetime.now()
#
#     graphSaver = SaveGraph(xlsm_file_name=r'C:\Users\eztihja\Copy of ENM_WORKLOAD_18.04_revF402.xlsm', path_where_to_save=Constants.graph_folder_path)
#     graphSaver.saveGraphsFromAllSheets(logging)
#
#     print datetime.now() - start
