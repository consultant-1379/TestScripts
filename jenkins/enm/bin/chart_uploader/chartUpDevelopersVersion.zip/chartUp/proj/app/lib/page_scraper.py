"""
Date: 07/2018
Author: Janis Tihonovs
"""
import re

import bs4 as bs


def scraper(page, tag, data_type, name):
    """
    example:
    soup.find_all("li", {"class": "child-item"})
    """
    soup = bs.BeautifulSoup(page.text, 'lxml')
    return soup.find_all(tag, {data_type: name})

def check_if_part_of_endurance_testing(page):
    parent = scraper(page=page, tag="a",data_type="class", name="parent-item-link")[0]
    if parent.get("title") == "Endurance Test Reports":
        return True
    return False

def get_confluence_child_page_titles(page):
    # Find page ID by confluence child page title
    confluence_child_pages_list = scraper(page=page, tag="li", data_type="class", name="child-item")
    return [child.text for child in confluence_child_pages_list]

# def get_attachment_id(page, file_name):
#     soup =bs.BeautifulSoup(page.text, 'lxml')
#     confluence_child_pages_list= soup.find_all("tr", {"data-attachment-filename": file_name})
#     return confluence_child_pages_list[0].get("id")

def find_html_by_title(confluence_main_page, session, page_header):
    page_html = session.get(url=confluence_main_page)
    confluence_child_pages_list = scraper(page=page_html, tag="li", data_type="class", name="child-item")
    for child in confluence_child_pages_list:
        if page_header in child.text:  # child.text is child page title
            return child


# def uppercase_and_substitute_html_entities(str):
#     return EntitySubstitution.substitute_html(str.upper())


def get_current_edit_page_body(page_url, session, log):
    """Return content of text area (Without textarea html headers)"""
    try:
        page_html = session.get(url=page_url)
        soup = bs.BeautifulSoup(page_html.text, 'lxml')
        current_page_body= soup.find("textarea", {"id": "wysiwygTextarea"})
        current_page_body =  current_page_body.prettify(formatter=None)
        return re.sub(r'<textarea.*?>', r'', current_page_body)[:-(len("</textarea>")+1)]
    except Exception as e:
        raise e
