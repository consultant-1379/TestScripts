import shutil

import os

from app.bin.helpers import popup

from app.lib import page_scraper
from app.lib.constants import Constants
from app.lib.save_graph import SaveGraph


class PostHelper:

    confluence_page_html = None
    def __init__(self):
        self.graphSaver = None


    def check_if_excel_file_extension(self, file_path):
        excel_file_extensions = ['.xlsx', '.xlsm']
        try:
            if file_path[-5:] in excel_file_extensions:
                return True
            else:
                raise IndexError()
        except IndexError:
            """
            If statement can raise index error, and if its in else it might as well
                go there since same message should be displayed.
            """
            alert_text = "Path should point to file with one of those extensions:\n{0}".format(excel_file_extensions)
            popup.Alert().warning_alert(title='Wrong file!', text=alert_text)
            raise ValueError()

    def save_graphs(self, file_path, log):
        # Use lib/graph folder to store and extract images

        try:
            self.graphSaver = SaveGraph(xlsm_file_name=file_path, path_where_to_save=Constants.graph_folder_path)
            self.graphSaver.saveGraphsFromAllSheets(log)
        except Exception:
            alert_text = "File: '{0}' could not be opened!".format(file_path)
            popup.Alert().warning_alert(title='Wrong file!', text=alert_text)

            raise ValueError()


    def check_confluence_html(self, confluence_url):
        """
        Check if valid url and than save it.
        """
        try:
            session = Constants.session
            page_html = session.get(url=confluence_url)

            if page_html.status_code == 200 and page_scraper.check_if_part_of_endurance_testing(page_html):
                Constants.confluence_page_html= page_html
                return
            raise Exception()
        except Exception as e:
            alert_text = "'{0}' is not valid url!\nURL should be child page of Endurance Test Reports\n" \
                         "Example of valid url:\n'https://confluence-nam.lmera.ericsson.se/display/TORRV/18.04+ENM+60K+Test+Report'".format(confluence_url)
            popup.Alert().warning_alert(title='Bad URL!', text=alert_text)
            print e
            raise ValueError()

    def check_if_session_expired(self, check_url="https://confluence-nam.lmera.ericsson.se/users/viewmyprofile.action"):
        """This page can be accessed only if person is logged in. If not, it will be redirected to login page."""

        r = Constants.session.get(url=check_url)
        if "login.action" in r.url:
            popup.Alert().userLogin()
            raise ValueError("Page got redirected. Value error raised.")

    def delete_old_graphs(self):
        try:
            shutil.rmtree(Constants.graph_folder_path)
            os.makedirs(Constants.graph_folder_path)
        except WindowsError:
            # if file already was deleted than shutil.rmtree will throw error.
            try:
                os.makedirs(Constants.graph_folder_path)
            except WindowsError:
                pass

    @staticmethod
    def GetGraphSaver():
        return PostHelper.graphSaver