import os.path
from kivy.core.window import Window


class Constants:

    session = None
    dirname = os.path.split(os.path.abspath(__file__))[0]
    graph_folder_path = dirname + "\graphs"
    DOCS_PATH = dirname + r"\..\bin\HowTo.txt"
    confluenceVsExcelFilePath = dirname + '\confluenceVsExcel.txt'
    WINDOW_WIDTH = Window.width
    WINDOW_HEIGT = Window.height
    WIDTH_OF_DROP_TO_IN_POST_NEXT = WINDOW_WIDTH * 0.7
    POST_NEXT_BUTTON_HEIGHT = 30
    LOGGER = None

