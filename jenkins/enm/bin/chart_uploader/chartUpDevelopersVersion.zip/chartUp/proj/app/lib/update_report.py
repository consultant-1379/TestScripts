import json
import re
import mimetypes
import requests
import time

from collections import defaultdict
from requests_toolbelt import MultipartEncoder

import page_scraper
from constants import Constants

url = 'https://confluence-nam.lmera.ericsson.se/pages/doattachfile.action?pageId=242800892'


class UpdateReport:
    def __init__(self, confluence_page, session=Constants.session):
        self.confluence_page = confluence_page
        self.session = session

    @property
    def confluence_page(self):
        return self.confluence_page

    @confluence_page.setter
    def confluence_page(self, v):
        self.confluence_page = v

    def push_image_on_server(self, page_header, files, log):
        try:
            page_id = self.get_report_page_id(page_header=page_header)
            log.info("\nUploading to page " + page_header + ", page id: " + page_id)

            # Send files to this page
            dict_of_current_attachments = self.get_current_attac_names_and_ids(page_id=page_id)
            add_observation_edit_val = ""

            for file in files:
                try:
                    file_name = file.split("\\")[-1:][0]
                    log.info("\t\tUploading file: "+ file_name)
                    multipart_encoder = self.get_file_multipart_encoder(file_path=file, file_name=file_name)

                    if file_name in dict_of_current_attachments.keys():
                        """If image is already uploaded, than update it with new version."""
                        attachment_id = dict_of_current_attachments[file_name]
                        r = self.update_picture_in_attachemnts(page_id=page_id,
                                                               file_multipart_encoder=multipart_encoder,
                                                               attachment_id=attachment_id,
                                                               log=log)
                    else:
                        r = self.upload_picture_to_attachments(page_id=page_id,
                                                               file_multipart_encoder=multipart_encoder,
                                                               log=log)
                        # new attachment with new ID
                        attachment_id = json.loads(r.text)["results"][0]["id"][len("att"):]

                    if r.status_code != 200:
                        raise Exception("Something went wrong, file did not uploaded/updated")

                    add_observation_edit_val += self.get_image_editor_value(title=page_header,
                                                                            page_id=page_id,
                                                                            attachment_id=attachment_id,
                                                                            file_name=file_name).decode("utf-8")
                    log.info("\t\t\t\tdone!\n")
                except Exception as e:
                    print e
                    log.error("\t\t\t\tImage could not be uploaded!!! skipping...\n")
            try:
                body_editor_value = self.edit_report_page_value(page_id=page_id, log=log, add_observation_edit_val = add_observation_edit_val)
                self.update_page_with_image(page_id=page_id, body_editor_value=body_editor_value, log=log)
            except Exception as e:
                log.error("Could not edit page content!!!")
                raise Exception(e)



            log.info("\t\t\t\tPage " + page_header + " is updated.")
            log.info("-="*50)
        except Exception as e:
            log.error("skipping uploads for " + page_header + "...")
            print e
        finally:
            time.sleep(1)

    def edit_report_page_value(self, page_id, log, add_observation_edit_val):
        """Check if has Key observations header, add 'add_observation_edit_val' under that header, if doesn't have it than add at the top.
        add_observation_edit_val that represents a new html code value that is to be added to existing content. Effectively speaking It contains new uploaded images that needs to be added to content."""
        log.info("\t\tEditing page content...")
        edit_page_url = "https://confluence-nam.lmera.ericsson.se/pages/editpage.action?pageId=" + page_id
        body_editor_value = page_scraper.get_current_edit_page_body(page_url=edit_page_url, session=self.session, log=log)
        if not 'Key Observations' in body_editor_value:
            return add_observation_edit_val + body_editor_value
        else:
            """Add updated Key Observation code to editor value"""
            add_observation_edit_val = self.get_observations_table_code(body_editor_value=body_editor_value) + add_observation_edit_val
            body_editor_value = re.sub(r'(<p>.*?Key Observations.*?)(<h\d>)',
                                       r'\1{0}\2'.format(add_observation_edit_val),
                                       body_editor_value)
            """Add updated Known Issues code to editor value"""
            add_known_issues_edit_val = self.get_jira_table_code(body_editor_value)
            return re.sub(r'(<p>.*?Known Issues.*?</h\d>)', r'\1' + add_known_issues_edit_val,
                                       body_editor_value)

    def get_report_page_id(self, page_header):
        page_html = page_scraper.find_html_by_title(confluence_main_page=self.confluence_page,
                                                    session=self.session,
                                                    page_header=page_header)

        return page_html.get("data-page-id")  # From 'Test 3' get page id like 201234

    def get_observations_table_code(self, body_editor_value):
        """
        This method checks if there is observations table under 'Key Observations'.
        If there is no table generated already than it will return default table code, else empty string
        """
        key_obs =  re.findall(r'(<h\d>.*?Key Observations.*?<h\d>)', body_editor_value)[0]
        if 'class="confluenceTh">Observation' not in key_obs:
            return "<table class=\"confluenceTable\">" \
                       "<colgroup>" \
                           "<col /><col />" \
                       "</colgroup>" \
                       "<tbody>" \
                           "<tr>" \
                               "<th class=\"confluenceTh\"><br /></th>" \
                               "<th class=\"confluenceTh\">Observations</th>" \
                           "</tr>" \
                           "<tr>" \
                               "<th class=\"confluenceTh\">1.</th>" \
                               "<td class=\"confluenceTd\"><br /></td>" \
                           "</tr>" \
                           "<tr>" \
                               "<th class=\"confluenceTh\">2.</th>" \
                               "<td class=\"confluenceTd\"><br /></td>" \
                           "</tr>" \
                           "<tr>" \
                               "<th class=\"confluenceTh\">3.</th>" \
                               "<td class=\"confluenceTd\"><br /></td>" \
                           "</tr>" \
                        "</tbody>" \
                    "</table>"
        return ""

    def get_jira_table_code(self, body_editor_value):
        """
        This method checks if there is issue table under 'Known Issues'.
        If there is no table generated already than it will return default table code, else empty string
        """
        key_obs = re.findall(r'(<h\d>.*?Known Issues.*?<h\d>)', body_editor_value)[0]

        if 'class="confluenceTh">Jira ID' not in key_obs:
            return \
                "<table class=\"confluenceTable\">" \
                    "<colgroup>" \
                        "<col /><col /><col /><col />" \
                    "</colgroup>" \
                    "<tbody>" \
                        "<tr>" \
                            "<th class=\"confluenceTh\"><br /></th>" \
                            "<th class=\"confluenceTh\">Jira ID</th>" \
                            "<th class=\"confluenceTh\">Jira Slogan</th>" \
                            "<th class=\"confluenceTh\">Comment</th></tr><tr>" \
                            "<th class=\"confluenceTh\">1.</th>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                            "<td class=\"confluenceTd\"><br /></td></tr><tr>" \
                            "<th class=\"confluenceTh\">2.</th>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                            "<td class=\"confluenceTd\"><br /></td></tr><tr>" \
                            "<th class=\"confluenceTh\">3.</th>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                            "<td class=\"confluenceTd\"><br /></td>" \
                        "</tr>" \
                    "</tbody>" \
                "</table>"
        return ""

    def get_file_multipart_encoder(self, file_path, file_name):
        mimetypes.init()
        attachmentType = mimetypes.guess_type(file_path, strict=True)

        return MultipartEncoder(
            fields={'encodedComment': ''.encode('utf-8'),
                    'file': (
                        file_name,
                        open(file_path, 'rb'), attachmentType[0])}
        )

    def upload_picture_to_attachments(self, page_id, file_multipart_encoder, log):

        headers = {'X-Atlassian-Token': 'no-check',
                   'Content-Type': file_multipart_encoder.content_type}
        attachment_url = "https://confluence-nam.lmera.ericsson.se/rest/api/content/{0}/child/attachment".format(page_id)
        r = self.session.post(url=attachment_url,
                              headers=headers,
                              verify=False,
                              data=file_multipart_encoder)
        if r.status_code != 200:
            log.error("Image could not be uploaded!!! skipping...")
            raise Exception("Image could not be uploaded!!! skipping...")
        return r

    def update_picture_in_attachemnts(self, page_id, file_multipart_encoder, attachment_id, log):
        headers={'X-Atlassian-Token': 'no-check', 'Content-Type': file_multipart_encoder.content_type}
        attachment_url="https://confluence-nam.lmera.ericsson.se/rest/api/content/{0}/child/attachment/{1}/data".format(
            page_id, attachment_id)
        r = self.session.post(url=attachment_url,
                              headers=headers,
                              verify=False,
                              data=file_multipart_encoder)
        if r.status_code != 200:
            log.error("Image was not updated, skipping...")
            raise Exception("Image was not uploaded")
        return r

    def get_image_editor_value(self, title, page_id, attachment_id, file_name):
        """
        Note. 'd  ata-linked-resource-type' should contain that weird double space otherwise it will upload image
        in a way you wont be able to open it, but just download.
        """
        return "<p><img class=\"confluence-embedded-image\" " \
               "width=\"900\"" \
               "src=\"https://confluence-nam.lmera.ericsson.se/download/attachments/{0}/{2}?version=1&amp;" \
               "api=v2\" " \
               "data-image-src=\"/download/attachments/{0}/{2}?version=1&amp;" \
               "api=v2\" " \
               "data-unresolved-comment-count=\"0\" " \
               "data-linked-resource-id=\"{1}\" " \
               "data-linked-resource-version=\"1\" " \
               "data-linked-resource-type=\"attachment\" " \
               "data-linked-resource-default-alias=\"{2}\" " \
               "data-base-url=\"https://confluence-nam.lmera.ericsson.se\" " \
               "data-linked-resource-content-type=\"image/png\" " \
               "data-linked-resource-container-id=\"{0}\" " \
               "data-linked-resource-container-version=\"2\" " \
               "data-location=\"TOR_RV &gt; {3} &gt; {2}\" " \
               "</p>" \
               "<p><br /></p>".format(page_id, attachment_id, file_name.encode('utf-8'), title.encode('utf-8'))


    def update_page_with_image(self, page_id, body_editor_value, log):
        try:
            data = self.session.get("https://confluence-nam.lmera.ericsson.se/rest/api/content/{0}".format(page_id)).json()
            next_version = data['version']['number'] + 1
            title = data['title']
            payload = {
                "status": "current",
                "title": title,
                "space": {"key": "TORRV"},
                "body": {"editor": {
                    "value": body_editor_value,
                    "representation": "editor",
                    "content": {"id": page_id}}},
                "id": page_id,
                "type": "page",
                "version": {"number": next_version,
                            "message": "",
                            "syncRev": "dummy-sync-rev"},
            }

            r = self.session.put(
                url="https://confluence-nam.lmera.ericsson.se/rest/api/content/{0}".format(page_id),
                data=json.dumps(payload),
                headers={
                    'Content-Type': 'application/json; charset=UTF-8',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
                    "X-Atlassian-Token": "no-check",
                    'Referer': 'https://confluence-nam.lmera.ericsson.se/pages/editpage.action?pageId={0}'.format(page_id),
                }
            )
            if r.status_code != 200:
                raise Exception()

        except Exception as e:
            log.error("Could not update page content!!!")
            raise Exception(e)

    def get_current_attac_names_and_ids(self, page_id):
        """
        :return: defaultdict(<type 'str'>, {u'<picture_name>.png': u'att<ID>', ...})
        """
        try:
            page_html = self.session.get(url="https://confluence-nam.lmera.ericsson.se/rest/api/content/{0}/child/attachment".format(page_id))
            d = defaultdict(str)
            for x in json.loads(page_html.text)["results"]:
                d[x["title"]] = (x["id"])
            return d
        except Exception as e:
            raise Exception(e)


# if __name__ == '__main__':
#     Constants.session = requests.session()
#     Constants.session.post(url="https://confluence-nam.lmera.ericsson.se/dologin.action",
#                            data={"os_username": user.name, "os_password": user.name2})
#     import logging
#     handler = logging.FileHandler("example.log")
#     logger = logging.getLogger("What ever")
#     logger.setLevel(logging.INFO)
#     logger.addHandler(handler)
#
#     UpdateReport(
#                         confluence_page="https://confluence-nam.lmera.ericsson.se/display/TORRV/18.04+ENM+60K+Test+Report",
#                         session=Constants.session
#                         ).push_image_on_server(page_header="test5",
#                                                files=[
#                                                    r'C:\Users\eztihja\PycharmProjects\graphUp\app\bin\lib\graphs\BUR24052018.png',
#                                                    r'C:\Users\eztihja\PycharmProjects\graphUp\app\bin\lib\graphs\CPPNE24052018.png'
#                                                ],
#                                                log=logger)
