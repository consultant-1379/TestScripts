import logging
import sys
import traceback

from app.lib.constants import Constants


def setup_logger(name, log_file, level=logging.INFO):
    """Function setup as many loggers as you want"""
    logging.StreamHandler(sys.stderr)
    handler = logging.FileHandler(log_file)
    handler.setFormatter(SpecialFormatter())

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    logger.propagate = False
    return logger


class SpecialFormatter(logging.Formatter):
    FORMATS = {logging.DEBUG :"DBG: %(module)s : %(lineno)d: %(message)s",
               logging.ERROR : "%(levelname)s %(asctime)s: %(message)s",
               logging.INFO : "%(levelname)s %(asctime)s: %(message)s",
               'DEFAULT' : "%(levelname)s: %(asctime)s: %(message)s",
               }

    def format(self, record):
        self._fmt = self.FORMATS.get(record.levelno, self.FORMATS['DEFAULT'])
        self.datefmt = '%H:%M'
        return logging.Formatter.format(self, record)


def log_traceback(e, level="ERROR"):
    if level is "ERROR":
        _, _, ex_traceback = sys.exc_info()
        msg = [line.rstrip('\n') for line in
                    traceback.format_exception(e.__class__, e, ex_traceback)]
    else:
        msg = e
    Constants.LOGGER.log(level=logging.getLevelName(level), msg=msg)