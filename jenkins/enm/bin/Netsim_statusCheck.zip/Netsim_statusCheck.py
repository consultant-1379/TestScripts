#! /usr/bin/python
import socket
import time
import subprocess
import sys
import os
import json
import datetime

def clean_up():
    print ("Files older than 3 days are deleted.....!!!!!!!\n ")
    find = "find /root/rvb/bin/LOGS -mtime +3 -name '*.txt'"
    del_find = "find /root/rvb/bin/LOGS -mtime +3 -name '*.txt' -delete"
    os.system(find)
    os.system(del_find)

def check_main():
    Host = "ieatwlvm5041"
    print ("\nChecking the status of Netsim's...This operation can take some time. Please be patient...!!!!!\n")
    command = "cd /root/rvb/bin/; sh netsim_check.sh > temp.txt; sed -r 's/\x1B\[[0-9;]*[a-zA-Z]//g' temp.txt > netsimCheck_output.txt; scp netsimCheck_output.txt ieatlms4074-1:/root/rvb/bin/"
    ssh = subprocess.Popen(["ssh", "%s" % Host, command], shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    result = ssh.stdout.readlines()

check_main()

with open('/root/rvb/bin/netsimCheck_output.txt') as f:
    buff = f.read()
#print len(buff)
# no simulations on netsim
def error_nosim(buff):
    err1 = "There are no simulations on "
    text_length = len(err1)
    li = []
    res = [i for i in range(len(buff)) if buff.startswith(err1, i)]
    #print(res)
    if len(res) > 0:
        for index in res:
            li.append(buff[buff.index('ieatnetsimv',(index - 137)): buff.index('\nNetsim', (index - 138))])        
        return li
    else:
        return li

def error_ping(buff):
    err2 = "Unable to ping netsim "
    text_length = len(err2)
    li = []
    res = [i for i in range(len(buff)) if buff.startswith(err2, i)]
    #print(res)
    if len(res) > 0:
        for index in res:
            li.append(buff[buff.index('ieatnetsimv',(index - 137)): buff.index('\nEncountered', (index - 138))])
        return li
    else:
        return li

def error_restart(buff):
    err3 = r"> <installation-directory>/restart_netsim"
    text_length = len(err3)
    li = []
    res = [i for i in range(len(buff)) if buff.startswith(err3, i)]
    #print(res)
    if len(res) > 0:
        for index in res:
            li.append(buff[buff.index('ieatnetsimv',(index - 137)): buff.index('\nNetsim', (index - 138))])
        return li
    else:
        return li
		
def error_notstarted(buff):
    err4 = "!!!! NETSim is not started for this installation. The following error was reported:"
    text_length = len(err4)
    li = []
    res = [i for i in range(len(buff)) if buff.startswith(err4, i)]
    #print(res)
    if len(res) > 0:
        for index in res:
            li.append(buff[buff.index('ieatnetsimv',(index - 137)): buff.index('\nNetsim', (index - 138))])
        return li
    else:
        return li

def error_nodedown(buff):
    err5 = "nodedown,'coordinator_netsim"
    text_length = len(err5)
    li = []
    res = [i for i in range(len(buff)) if buff.startswith(err5, i)]
    #print(res)
    if len(res) > 0:
        for index in res:
            li.append(buff[buff.index('ieatnetsimv',(index - 137)): buff.index('\nNetsim', (index - 138))])
        return li
    else:
        return li

Current_Date = datetime.datetime.today().strftime ('%d-%b-%Y_%I-%M-%S_%p')
filename = '/root/rvb/bin/LOGS/FinalOutput_' + str(Current_Date) + '.txt'
with open(filename, 'w') as file:
    error1 = error_nosim(buff)
    error2 = error_ping(buff)
    error3 = error_restart(buff)
    error4 = error_notstarted(buff)
    error5 = error_nodedown(buff) 
    combined = error1+ error2+ error3+ error4+ error5
    data2_json = json.dumps(combined, indent = 6)
    if len(combined)==0:
        file.write("\nNetsim status check Successfully Completed....All netsims are online\n \n \n ################################*******################################\n \n You can see the final output file under /root/rvb/bin/LOGS path in LMS\n \n ################################*******################################\n \n")
    else:
        file.write("\nNetsim status check failed. Below netsims are down:\n" + data2_json + "\n ################################*******################################\n \n You can see the final output file under /root/rvb/bin/LOGS path in LMS\n \n ################################*******################################\n \n") 

r = os.popen('cat ' + filename).read()
print (r)
clean_up()
