#! /bin/bash
for i in `cat /var/tmp/netsim_list` ; do echo $i; /opt/ericsson/nssutils/bin/netsim list $i ; done

