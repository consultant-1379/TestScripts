#########README file to follow the instructions

1. copy the zip file and extract it in LMS
#cd /ericsson/enm/dumps/
# unzip -o /root/rvb/bin/ShmLogCollection.zip -d /ericsson/enm/dumps/

2. Create the following directories in LMS if not created by the step#1
#mkdir -p /ericsson/enm/dumps/ShmLogCollection/{bin,etc,log}

3. Update the file permissions to 755
# chmod 755 ericsson/enm/dumps/ShmLogCollection/bin/*.*

4. Run the InitialSetup.sh script by passing
   a. the Cluster id to get workload vm IP from DMT

#sh /ericsson/enm/dumps/ShmLogCollection/bin/InitialSetup.sh <636>

5. Check the nodes and netsim mapping list created in /ericsson/enm/dumps/ShmLogCollection/etc/netsim_nodes_list.txt

6. Check the module "ShmLogCollectionModule" created in FMx

#ssh -i /root/.ssh/vm_private_key cloud-user@svc-3-fmx 'fmxcli -c list'

Note: FMx starts listens new alarm from SHM if any job fails based on the rule and trigger the script to collect logs,
After the Initial setup in step#3

7. Job logs will be copied to /ericsson/enm/dumps/ShmLogCollection/log/<JobName>

8. If any issue with script then look at /ericsson/enm/dumps/ShmLogCollection/log/script.log

9. For deactivate and deleting the FMx module

#sh /ericsson/enm/dumps/ShmLogCollection/bin/TearDown.sh



NOTE:
You shall update the /ericsson/enm/dumps/ShmLogCollection/etc/.shmlogcollectionconfig file
if any other SHM profiles want to monitor for failures.
Make sure you add the profile name with the correct mediation

