#!bin/sh/bash

cli_app 'shm status --all'|grep $(date +%d/%m/%Y)|egrep "FAILED" > ShmJobStatus.txt

if [ -s ShmJobStatus.txt ]
then

        echo ""
        echo "=========================================================================================="
                echo "Below are the Failed SHM jobs as on  $(date +%b" "%d)"
        echo "=========================================================================================="

      #cat ShmJobStatus.txt

      echo ""
          echo -e "\e[1;34mFailed SHM Backup Jobs:\e[0m" | sed "s/^/\t/g"

  cat ShmJobStatus.txt | egrep -w "BACKUP" | egrep "FAILED|SKIPPED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;34mFailed SHM Backup Housekeeping Jobs:\e[0m" | sed "s/^/\t/g"
  cat ShmJobStatus.txt | egrep -w "BACKUP_HOUSEKEEPING" | egrep "FAILED|SKIPPED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;32mFailed SHM Delete Backup Jobs:\e[0m" | sed "s/^/\t/g"
  cat ShmJobStatus.txt | egrep -w "DELETEBACKUP" | egrep "FAILED|SKIPPED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;36mFailed SHM Upgrade Jobs:\e[0m" | sed "s/^/\t/g"
  cat ShmJobStatus.txt | egrep -w "UPGRADE" | egrep "FAILED|SKIPPED" | sed "s/^/\t/g"
  echo ""

  echo -e "\e[1;36mFailed SHM Delete Upgrade Package Jobs:\e[0m" | sed "s/^/\t/g"
  cat ShmJobStatus.txt | egrep -w "DELETE_UPGRADEPACKAGE" | egrep "FAILED|SKIPPED" | sed "s/^/\t/g"
  echo ""


        echo "=========================================================================================="
        echo "Failed jobs found. Copying logs..."
        echo "=========================================================================================="
        echo ""

     ssh root@$LMS_HOST /root/rvb/bin/BS_Automation/SHM_Usecase/ShmLogCollection.sh

         echo ""
         echo "=========================================================================================="
         echo "Logs successfully copied for failed jobs."
         echo "Please check /ericsson/enm/dumps/AutomatedLogCollection in LMS to see the logs."
         echo "=========================================================================================="
                 echo ""

else

        echo "=========================================================================================="
        echo "There are no failed jobs"
        echo "=========================================================================================="

fi


