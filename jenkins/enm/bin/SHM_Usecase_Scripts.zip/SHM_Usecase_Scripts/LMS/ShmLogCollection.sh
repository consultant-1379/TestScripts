#!/bin/bash

#script to collect shmvm logs

keypair="/var/tmp/enm_keypair.pem"

JBOSSLOG="/ericsson/3pp/jboss/standalone/log/server*"

for ip in $(awk '{print $2}' /etc/hosts | grep shm);
do
echo ""
   echo "============ ${ip} ============";
   ssh -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o ServerAliveInterval=150 -i /root/.ssh/vm_private_key cloud-user@${ip}  "exec sudo " tar -zcvf /ericsson/enm/dumps/AutomatedLogCollection/${ip}_$(date +'%F')_$(date +'%H%M%S')_server.log.tgz -P ${JBOSSLOG} 

done



echo ""
echo "Cleaning-up files older than 4 days..."
echo "..."
find /ericsson/enm/dumps/AutomatedLogCollection/* -mtime +4 -exec rm {} \;
echo "..."
echo "Clean-up done."
echo ""
